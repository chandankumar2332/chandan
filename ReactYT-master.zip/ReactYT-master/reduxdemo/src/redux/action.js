export const FETCH_REQ = 'FETCH_REQ';
export const FETCH_SUC = 'FETCH_SUC';
export const FETCH_FAIL = 'FETCH_FAIL';