let arr = ["Hi","I","am","Udai"];

// let a = arr[0];
// let b = arr[1];

//Destructuring
// let [a,b,c,d] = arr

// let [a,b,,d] = arr

let [a,b,c,d,extra='Hlo'] = arr

console.log(a,b,d,extra);