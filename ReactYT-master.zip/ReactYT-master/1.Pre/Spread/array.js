let arr = [1,2,3];

// let arr2 = arr;

// arr2.push(4);

// console.log(arr);
// console.log(arr2);

let arr2 = [...arr]

arr2.push(4);

console.log(arr);
console.log(arr2);