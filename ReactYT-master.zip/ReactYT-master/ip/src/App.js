import './App.css';
import Parent from './Parent';


function App() {
  return (
    <div className="App">
      <h1>Hooks</h1>
      <Parent/>
    </div>
  );
}

export default App;