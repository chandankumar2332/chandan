import React from 'react';
const context = React.createContext('hello');
export default context;